package com.zhengyuan.liunao.tools;

public class UserPersission {
	

}
